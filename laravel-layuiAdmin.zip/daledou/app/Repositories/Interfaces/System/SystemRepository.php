<?php

namespace App\Repositories\Interfaces\System;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserRepository.
 */
interface SystemRepository extends RepositoryInterface
{


}
