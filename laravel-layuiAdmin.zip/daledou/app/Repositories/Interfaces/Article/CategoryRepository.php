<?php

namespace App\Repositories\Interfaces\Article;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserRepository.
 */
interface CategoryRepository extends RepositoryInterface
{


}
